console.log('hi');
document.write('');